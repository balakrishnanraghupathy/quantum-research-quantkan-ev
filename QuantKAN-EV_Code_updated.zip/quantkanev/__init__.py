"""
QuantKAN-EV
-----------
A Quantum-Inspired Kolmogorov-Arnold Network Framework for Cross-Domain
State of Health Estimation and Capacity Fade Prediction in Electric
Vehicle Lithium-Ion Batteries.

Reference implementation of the architecture, training, and cross-domain
adaptation procedure described in the manuscript (Sections 3.1-3.10,
Algorithms 1-2, Equations 1-19). Provided under the manuscript's Data
Availability Statement for reproducibility.

Modules
-------
activation      : the quantum-inspired per-edge activation unit (Eq. 5-9)
layers          : QuantKAN layer + adaptive spline fusion (Eq. 3, 11-12)
model           : full QuantKAN-EV backbone with dual-head output (Table 5)
capacity_fade   : monotonic capacity-fade forecasting head (Eq. 17-18)
losses          : multi-task loss (Eq. 13-16)
domain_adapt    : feature-statistics alignment + selective fine-tuning
                  (Eq. 19, Algorithm 2)
train_source    : source-domain pretraining loop (Algorithm 1)
train_adapt     : cross-domain adaptation loop (Algorithm 2)
metrics         : evaluation metrics (Eq. 20-23)
data_pipeline   : preprocessing pipeline stubs (Stage II, Section 3.2)
config          : hyperparameters (Table 8)
"""

from .config import QuantKANEVConfig

__all__ = ["QuantKANEVConfig"]
__version__ = "1.0.0"
