"""Figure 10 (Section 4.9): edge-averaged coupling matrix and rotation scales of a
trained QuantKAN layer.

    W_bar[j,k]  = (1/(n*m)) sum_q sum_p W[q,p,j,k]        (3 x 3, gate channels)
    alpha_bar_k = (1/(n*m)) sum_q sum_p alpha[q,p,k]

Usage:  python tools/extract_coupling.py --checkpoint trained.pt --out fig10.png
Without --checkpoint the untrained model is used (W_bar = I, alpha_bar = 1): this
only exercises the code path and must NOT be used as a paper figure.
"""
import argparse, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np, torch
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from quantkanev.config import QuantKANEVConfig
from quantkanev.model import QuantKANEV

GATES = ["Ry", "Rz", "Rx"]


def edge_averages(layer):
    W = layer.W.detach().mean(dim=(0, 1)).numpy()          # (Q, Q)
    alpha = layer.alpha.detach().mean(dim=(0, 1)).numpy()  # (Q,)
    return W, alpha


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--out", default="fig10.png")
    a = ap.parse_args()
    model = QuantKANEV(QuantKANEVConfig())
    if a.checkpoint:
        model.load_state_dict(torch.load(a.checkpoint, map_location="cpu"))
    W1, al1 = edge_averages(model.layer1)
    _, al2 = edge_averages(model.layer2)
    print("W_bar (layer 1):\n", np.round(W1, 4)); print("alpha_bar layer1:", np.round(al1, 4), "layer2:", np.round(al2, 4))
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.8), dpi=200)
    v = max(1.0, float(np.abs(W1).max()))
    im = ax[0].imshow(W1, cmap="RdBu_r", vmin=-v, vmax=v)
    for i in range(3):
        for j in range(3): ax[0].text(j, i, f"{W1[i,j]:.2f}", ha="center", va="center", fontsize=9)
    ax[0].set_xticks(range(3), GATES); ax[0].set_yticks(range(3), GATES)
    ax[0].set_title("(a) Edge-averaged coupling matrix $\\bar W$, Layer 1", fontsize=10); fig.colorbar(im, ax=ax[0], fraction=0.046)
    A = np.stack([al1, al2]); im2 = ax[1].imshow(A, cmap="viridis")
    for i in range(2):
        for j in range(3): ax[1].text(j, i, f"{A[i,j]:.2f}", ha="center", va="center", color="w", fontsize=9)
    ax[1].set_xticks(range(3), GATES); ax[1].set_yticks(range(2), ["Layer 1", "Layer 2"])
    ax[1].set_title("(b) Edge-averaged rotation scale $\\bar\\alpha_k$", fontsize=10); fig.colorbar(im2, ax=ax[1], fraction=0.046)
    fig.tight_layout(); fig.savefig(a.out); print("saved", a.out)


if __name__ == "__main__":
    main()
