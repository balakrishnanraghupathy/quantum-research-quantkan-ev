"""Section 4.13 / Figure 13: robustness to randomly missing field data.

Protocol: mask a fraction r in {0, .1, .2, .3} of the channel-time-step entries of
each evaluation window at random, replace each masked entry by the per-channel
TRAINING mean, and re-evaluate the adapted model without retraining. Accuracy is
100 x (1 - MAE) (Eq. 20), computed from the MAE of the same condition.

    from tools.robustness_missing import masked_evaluation
    table = masked_evaluation(model, eval_loader, channel_means, rates=(0,.1,.2,.3), seeds=range(5),
                              align=lambda x: align_features(x, mu_s, sigma_s, mu_t, sigma_t))
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np, torch
from quantkanev.metrics import evaluate_all


@torch.no_grad()
def masked_evaluation(model, loader, channel_means, rates=(0.0, 0.1, 0.2, 0.3), seeds=range(5), align=None):
    model.eval(); out = {}
    for r in rates:
        per_seed = []
        for s in seeds:
            g = torch.Generator().manual_seed(1000 * s + int(r * 100))
            yh, yt = [], []
            for x, c, soh, _ in loader:
                mask = torch.rand(x.shape, generator=g) < r
                x = torch.where(mask, channel_means.view(1, 1, -1).expand_as(x), x)
                if align is not None:
                    b, w, d = x.shape; x = align(x.reshape(b * w, d)).reshape(b, w, d)
                pred, _ = model(x, c)
                yh.append(pred.numpy()); yt.append(soh.numpy())
            per_seed.append(evaluate_all(np.concatenate(yh), np.concatenate(yt)))
        out[r] = {k: (float(np.mean([m[k] for m in per_seed])), float(np.std([m[k] for m in per_seed]))) for k in per_seed[0]}
    return out


if __name__ == "__main__":  # smoke test on synthetic data (code-path check only)
    from torch.utils.data import DataLoader, TensorDataset
    from quantkanev.config import QuantKANEVConfig
    from quantkanev.model import QuantKANEV
    torch.manual_seed(0); cfg = QuantKANEVConfig(); m = QuantKANEV(cfg)
    x = torch.randn(128, cfg.window_length, cfg.input_dim); c = torch.rand(128) + .5
    ds = TensorDataset(x, c, torch.rand(128), torch.rand(128, cfg.forecast_horizon))
    res = masked_evaluation(m, DataLoader(ds, batch_size=64), torch.zeros(cfg.input_dim), seeds=range(2))
    for r, v in res.items(): print(r, {k: round(t[0], 4) for k, t in v.items()})
