"""Table 20 / Section 4.10 measurements for QuantKAN-EV: parameter count, serialized
model size, FLOPs per sample, and CPU inference latency per sample.

Usage:  python tools/benchmark_table20.py [--checkpoint path.pt] [--threads 1]

Latency depends on the machine: run this on the same workstation that was used
for the baselines of Table 20 before copying the latency figure into the table.
"""
import argparse, io, json, os, statistics, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import torch
from torch.utils.flop_counter import FlopCounterMode
from quantkanev.config import QuantKANEVConfig
from quantkanev.model import QuantKANEV


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--repeats", type=int, default=500)
    a = ap.parse_args()
    torch.set_num_threads(a.threads)
    cfg = QuantKANEVConfig()
    model = QuantKANEV(cfg)
    if a.checkpoint:
        model.load_state_dict(torch.load(a.checkpoint, map_location="cpu"))
    model.eval()
    n = model.count_parameters()
    buf = io.BytesIO(); torch.save(model.state_dict(), buf)
    x = torch.randn(1, cfg.window_length, cfg.input_dim); c = torch.rand(1) + 0.5
    with torch.no_grad(), FlopCounterMode(display=False) as f:
        model(x, c)
    with torch.no_grad():
        for _ in range(100): model(x, c)
        t = []
        for _ in range(a.repeats):
            s = time.perf_counter(); model(x, c); t.append((time.perf_counter() - s) * 1e3)
    out = {
        "parameters": n,
        "float32_size_MB": round(n * 4 / 1e6, 3),
        "serialized_state_dict_MB": round(buf.tell() / 1e6, 3),
        "matmul_einsum_FLOPs_per_sample (2 x MAC)": f.get_total_flops(),
        "latency_ms_median": round(statistics.median(t), 3),
        "latency_ms_p95": round(sorted(t)[int(0.95 * len(t))], 3),
        "threads": a.threads, "torch": torch.__version__,
    }
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
